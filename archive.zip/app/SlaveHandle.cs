﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Documents;

namespace sound_test.app
{
    //need main handle sql lite and share it for is server
    class SlaveHandle
    {
        SlaveCom Com;
        string _TargetIp;
        string _port;

        /*running state*/
        bool isRunningTest;
        bool Reconnectsignal = false;
        bool _isconnect;

        bool isconnect
        {
            get { return _isconnect; }
            set
            {
                if (_isconnect != value)
                {
                    _isconnect = value;
                    if (_isconnect == true)
                        ConnectChange?.Invoke("connect");
                    else
                        ConnectChange?.Invoke("disconnect");
                }
            }
        }


        /*PlayList*/
        private List<string> _PlayList;
        /*parameter*/
        public int setVolume;

        public string[] ReadPlayList
        {
            get => _PlayList.ToArray();
        }

        List<string> PlayList
        {
            get => _PlayList;
            set
            {
                if (_PlayList != value)
                {
                    _PlayList = value;
                    PlayListUpdata?.Invoke(_PlayList.ToArray());
                }
            }
        }

        /*UI string bing*/

        /*ui respone action*/
        public event Action<string[]> PlayListUpdata;
        public event Action<string> ConnectChange;
        public event Action<string[]> PlayInfoUpdata;
        public event Action<string> TestRunStateChange;
        //public event Action<string[]> ConnectInfo;

        /*All thread*/
        Thread RunTest_thread;
        /*Thread signal*/
        public bool RunningTestExit;

        public string[] beginTest(int reqvolume)
        {
            setVolume = reqvolume;
            if (isRunningTest == true)
                return new string[] { "error", "test is running" };
            RunTest_thread = new Thread(TestHandle);
            RunTest_thread.Start();
            return new string[] { "success" };
        }


        public async Task<SlaveCom.TestResult> PlayMusic(string fileName, int Volume)
        {
            var task = await Com.TestCmd(fileName, Volume);
            return task;
        }
        public List<T> RandomSortList<T>(List<T> ListT)
        {
            Random random = new Random();
            List<T> newList = new List<T>();
            foreach (T item in ListT)
            {
                newList.Insert(random.Next(newList.Count + 1), item);
            }
            return newList;
        }

        bool RandDelayloop(string filename)
        {
            Random rand = new Random();
            var delays = rand.Next(5, 16);
            for (int i = 0; i < delays; i++)
            {
                if (RunningTestExit)
                    return false;
                string[] RunAfterstr = new string[]{
                    "RunAfter",$"{filename}",$"{delays-i}"};
                PlayInfoUpdata?.Invoke(RunAfterstr);
                Thread.Sleep(1000);
            }
            return true;
        }

        public string RequirSignalTest(string filename, int setVolume)
        {
            if (isRunningTest)
                return "Error please wait all test finish";
            singalTestloop(filename);
            return "OK";
        }

        private bool singalTestloop(string filename)
        {
            int stdVolume = setVolume;
            bool isSuccess = true;
            string[] playstateUpdata = new string[]{
                    "begintest",$"{filename}"};
            PlayInfoUpdata?.Invoke(playstateUpdata);

            var playtask = PlayMusic(filename, stdVolume);

            Task.WaitAll(playtask);
            var result = playtask.Result;
            if (result.isError.Length > 0)
            {
                isSuccess = false;
            }
            string[] resultstr = new string[]{
                    "result",$"{result.filename}",$"{result.isack}",$"{result.sec}",$"{result.isError}" };

            PlayInfoUpdata?.Invoke(resultstr);
            return isSuccess;
        }

        public SlaveHandle(string Ip, string port)
        {
            _TargetIp = Ip;
            _port = port;
            isconnect = false;
            Thread thread = new Thread(run);
            thread.Start();

        }

        public void Reconnect()
        {
            if (isconnect == false)
            {
                Reconnectsignal = true;
            }
        }


        void ClientConnectEvent(bool connected)
        {
            if (connected)
            {
                RunningTestExit = false;
                isconnect = true;
            }
            else
            {
                isconnect = false;
                RunningTestExit = true;
            }
        }
        //RunTest thread
        private void TestHandle()
        {
            isRunningTest = true;
            TestRunStateChange?.Invoke("begin test");
            List<string> testList = RandomSortList<string>(PlayList);
            PlayListUpdata?.Invoke(testList.ToArray());
            bool isSuccess = true;
            //随机
            foreach (var filename in testList)
            {
                if (RunningTestExit)
                    break;
                isSuccess = RandDelayloop(filename);
                if (isSuccess == false)
                    break;
                isSuccess = singalTestloop(filename);
                if (isSuccess == false)
                    break;
            }
            string Back = (isSuccess) ? "success" : "error";
            TestRunStateChange?.Invoke(Back);
            //检测结果
            isRunningTest = false;
        }


        async void run()
        {
            //tcp init

            Com = new SlaveCom();
            Com.ConnectedEvent += ClientConnectEvent;
            Com.Init(_TargetIp, _port);
            //connect and get all info
            PlayList = await Com.GetPlayList();

            // TestHandle();
            while (true)
            {
                //this loop is to handle all key handle
                //1 get run key
                //   1.1 new thread is running for handle the whole test event;
                //2 check host is running 
                //  if no halt all the thread and back to reconnect
                if (isconnect == false)
                {
                    //break;
                }
                if (Reconnectsignal)
                {
                    Reconnectsignal = false;
                    Com = new SlaveCom();
                    Com.ConnectedEvent += ClientConnectEvent;
                    if (Com.Init(_TargetIp, _port) == false)
                    {
                        ConnectChange?.Invoke("ReconnectFail");
                        Debug.WriteLine($"重连接失败{_TargetIp}");
                    }
                }
                Thread.Sleep(50);
            }
            Debug.WriteLine($"服务终止{_TargetIp}");
        }

    }


}
