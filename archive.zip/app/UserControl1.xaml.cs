﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using sound_test.app;
using sound_test.app.OCR;
using sound_test.dataStroage;
using static sound_test.dataStroage.MyDatabase;
using static wpfCamTest.IDcardOCR;

namespace sound_test
{
    /// <summary>
    /// UserControl1.xaml 的交互逻辑
    /// </summary>
    public partial class UserControl1 : UserControl, INotifyPropertyChanged
    {
        private string _ControlName;
        //tcpSever CtrlClient = new tcpSever();
        SlaveHandle slavehandle;
        string targetIp;
        string targetPort;
        /*ui value*/
        string _PersonIdinfoMsg;
        string _VolumeIndicator;

        public string PersonIdinfoMsg
        {
            get { return _PersonIdinfoMsg; }
            set
            {
                if (_PersonIdinfoMsg != value)
                {
                    _PersonIdinfoMsg = value;
                    OnPropertyChanged(nameof(PersonIdinfoMsg));
                }
            }
        }
        bool _canSaveResult;
        public bool AllowSaveResult
        {
            get { return _canSaveResult; }
            set
            {
                if (_canSaveResult != value)
                {
                    _canSaveResult = value;
                    OnPropertyChanged(nameof(AllowSaveResult));
                }
            }
        }

        bool _CanChangeVolume;
        public bool AllowChangeVolume
        {
            get { return _CanChangeVolume; }
            set
            {
                if (_CanChangeVolume != value)
                {
                    _CanChangeVolume = value;
                    OnPropertyChanged(nameof(AllowChangeVolume));
                }
            }
        }

        public string VolumeIndicator
        {
            get { return _VolumeIndicator; }
            set
            {
                if (_VolumeIndicator != value)
                {
                    _VolumeIndicator = value;
                    OnPropertyChanged(nameof(VolumeIndicator));
                }
            }
        }

        public int SetVolume
        {
            get { return volume; }
            set
            {
                if (volume != value)
                {
                    volume = (value > 60) ? 60 : value;
                    VolumeIndicator = $"{volume}%";
                    OnPropertyChanged(nameof(volume));
                }
            }
        }

        /*TestParameter*/
        int volume;

        //public string 
        //{
        //    get { return _PersonIdinfoMsg; }
        //    set
        //    {
        //        if (_PersonIdinfoMsg != value)
        //        {
        //            _PersonIdinfoMsg = value;
        //            OnPropertyChanged(nameof(PersonIdinfoMsg));
        //        }
        //    }
        //}
        /*persion info*/
        IDinfo indivdualInfo;
        public ObservableCollection<TaskItem> examDetail { get; set; }


        public UserControl1(string targetIP, string port)
        {
            InitializeComponent();
            examDetail = new ObservableCollection<TaskItem>();
            TaskListView.ItemsSource = examDetail;
            this.DataContext = this;
            targetIp = targetIP;
            targetPort = port;
            SlaveHandle_init(targetIP, port);
            // 初始化任务列表
            PersonIdinfoMsg = "未输入";
            SetVolume = 50;
            AllowChangeVolume = true;
            AllowSaveResult = false;
            //PersonIdInfo.Text = "未输入";

            ConnectLabel.Foreground = Brushes.Red;
            //this.DataContext = this;
        }

        void SlaveHandle_init(string targetIP, string port)
        {
            if (slavehandle != null)
            {
                //slavehandle.
            }
            slavehandle = new SlaveHandle(targetIP, port);
            slavehandle.PlayListUpdata += PlayListUpdataEvent;
            slavehandle.PlayInfoUpdata += PlayInfoUpdataEvent;
            slavehandle.ConnectChange += ConnectChangeEvent;
            slavehandle.TestRunStateChange += TestRunStateChangeEvent;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            slavehandle.beginTest(SetVolume);
        }

        void ConnectChangeEvent(string msg)
        {
            this.Dispatcher.Invoke(() =>
            {
                switch (msg)
                {
                    case "connect":
                        ConnectLabel.Content = "连接"; ConnectLabel.Foreground = Brushes.Green;
                        break;
                    case "disconnect":
                        ConnectLabel.Content = "连接断开"; ConnectLabel.Foreground = Brushes.Red;
                        break;
                    case "ReconnectFail":
                        ConnectLabel.Content = "重连接失败"; ConnectLabel.Foreground = Brushes.Red;
                        break;
                }
            });
        }

        void TestRunStateChangeEvent(string msg)
        {
            if (msg == "begin test")
            {
                AllowChangeVolume = false;
                AllowSaveResult = false;
            }
            else if (msg == "error")
            {
                AllowChangeVolume = true;
                AllowSaveResult = false;
            }
            else if (msg == "success")
            {
                AllowChangeVolume = true;
                AllowSaveResult = true;
            }
        }



        void PlayListUpdataEvent(string[] list)
        {
            this.Dispatcher.Invoke(() =>
            {
                examDetail.Clear();
                foreach (string item in list)
                {
                    TaskItem taskitem = new TaskItem();
                    taskitem.TaskName = item;
                    taskitem.Time = " ";
                    taskitem.Status = "未测试";
                    taskitem.StatusBrush = Brushes.Gray;
                    examDetail.Add(taskitem);
                }
                //Tasks[2].Status = "测试中...";
                //Tasks[2].StatusBrush = Brushes.DarkGreen;
            });
        }

        void PlayInfoUpdataEvent(string[] list)
        {
            this.Dispatcher.Invoke(() =>
            {
                if (list[0] == "begintest")
                {
                    string fileName = list[1];
                    var cell = examDetail.FirstOrDefault(t => t.TaskName == fileName);
                    if (cell != null)
                    {
                        TaskItem Newcell = new TaskItem();
                        Newcell.TaskName = cell.TaskName;
                        Newcell.Status = "测试中...";
                        Newcell.StatusBrush = Brushes.DarkGreen;
                        var index = examDetail.IndexOf(cell);
                        examDetail[index] = Newcell;
                    }
                }
                if (list[0] == "result")
                {
                    string fileName = list[1];
                    string isack = list[2];
                    string ackSec = list[3];
                    string iserror = list[4];
                    var cell = examDetail.FirstOrDefault(t => t.TaskName == fileName);
                    if (cell != null)
                    {
                        TaskItem Newcell = new TaskItem();
                        Newcell.TaskName = cell.TaskName;
                        Newcell.Time = "";
                        if (iserror.Length > 0)
                        {
                            Newcell.Status = iserror;
                            Newcell.StatusBrush = Brushes.OrangeRed;
                        }
                        else if (isack == "False")
                        {
                            Newcell.Status = "未通过";
                            Newcell.StatusBrush = Brushes.Red;
                        }
                        else
                        {
                            Newcell.Status = "通过";
                            Newcell.Time = ackSec;
                            Newcell.StatusBrush = Brushes.Green;
                        }
                        var index = examDetail.IndexOf(cell);
                        examDetail[index] = Newcell;
                    }
                }
                if (list[0] == "RunAfter")
                {
                    string fileName = list[1];
                    string Delay = list[2];
                    var cell = examDetail.FirstOrDefault(t => t.TaskName == fileName);
                    if (cell != null)
                    {
                        TaskItem Newcell = new TaskItem();
                        Newcell.TaskName = cell.TaskName;
                        Newcell.Status = $"{Delay}秒后开始";
                        Newcell.StatusBrush = Brushes.DarkGreen;
                        var index = examDetail.IndexOf(cell);
                        examDetail[index] = Newcell;
                    }
                }
            });
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var IdinfoDialog = new IDcardInfo();
            IDinfo dinfo = new IDinfo();
            IdinfoDialog.GetIdinfo += ((e) =>
            {
                dinfo = e;
                Debug.WriteLine("已经获取");
            });
            IdinfoDialog.ShowDialog();
            if (dinfo.IDnumber != null || dinfo.name != null)
            {
                indivdualInfo = dinfo;
                PersonIdinfoMsg = $"{dinfo.name},{dinfo.gender},{dinfo.IDnumber}";
                //PersonIdInfo.Text = $"{dinfo.name},{dinfo.gender},{dinfo.IDnumber}";
            }
            else
            {
                indivdualInfo = null;
                PersonIdinfoMsg = "未输入姓名";
                //PersonIdInfo.Text = "未输入姓名";
            }
        }

        void Button_Click2(object sender, RoutedEventArgs e)
        {
            if (indivdualInfo == null || examDetail.Count == 0)
            {
                MessageBox.Show("保存失败", "确认", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var person = new Person()
            {
                birthday = indivdualInfo.birthday,
                gender = indivdualInfo.gender,
                ID = indivdualInfo.IDnumber,
                name = indivdualInfo.name,
            };
            MyDatabase.CheckPersonExist(indivdualInfo.IDnumber, person);

            MyDatabase.TestReport examReport = new MyDatabase.TestReport();

            foreach (var item in examDetail)
            {
                examReport.ST.Add(new singalTest()
                {
                    FileName = item.TaskName,
                    Isack = item.Status,
                    RepTime = item.Time
                });

            }
            MyDatabase.AddReport(indivdualInfo.IDnumber, examReport);
            MessageBox.Show("保存成功", "确认", MessageBoxButton.OK, MessageBoxImage.Information);
            AllowSaveResult = false;
            return;
        }

        void Button_Click3(object sender, RoutedEventArgs e)
        {
            slavehandle.Reconnect();
        }

        public string ControlName
        {
            get => _ControlName;
            set
            {
                if (_ControlName != value)
                {
                    _ControlName = value;
                    LabelControlName.Content = _ControlName;
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


    }

    public class TaskItem
    {
        public string TaskName { get; set; }
        public string Status { get; set; }
        public string Time { get; set; }
        public Brush StatusBrush { get; set; }
    }
}


