﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LiteDB;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Windows;
using static sound_test.dataStroage.MyDatabase.Person;
using System.Xml.Linq;
using static sound_test.dataStroage.MyDatabase;
using System.ComponentModel;

namespace sound_test.dataStroage
{
    public class MyDatabase
    {
        const string DataAddr = @"Data.db";
        MyDatabase()
        {

        }

        public static void SettingInsert<T>(T item)
        {
            using (var db = new LiteDatabase(DataAddr))
            {
                var setting = db.GetCollection<T>("setting");

            }
        }

        public static void HistoryInsert<T>(T item)
        {
            using (var db = new LiteDatabase(DataAddr))
            {
                var History = db.GetCollection<T>("History");

            }
        }

        public static void CheckPersonExist(string ID, MyDatabase.Person PersonInfo)
        {
            using (var db = new LiteDatabase(DataAddr))
            {
                var History = db.GetCollection<Person>("History");
                //try
                //{
                var existingPerson = History.Find(x => x.ID == ID).FirstOrDefault();

                //}

                if (existingPerson == null)
                {
                    PersonInfo.ID = ID;
                    History.Insert(PersonInfo);
                }
            }
        }



        public static void AddReport(string ID, TestReport testReport)
        {
            using (var db = new LiteDatabase(DataAddr))
            {
                var History = db.GetCollection<Person>("History");
                var existingPerson = History.Find(x => x.ID == ID).FirstOrDefault();
                if (existingPerson != null)
                {
                    // 如果该电话号码已存在，更新记录，添加新的电话时间
                    existingPerson.Report.Add(testReport);
                    History.Update(existingPerson);  // 更新数据库中的记录
                }
            }
        }

        public static bool ReadReport(string ID, out List<TestReport> testReport)
        {
            using (var db = new LiteDatabase(DataAddr))
            {
                var History = db.GetCollection<Person>("History");
                var existingPerson = History.Find(x => x.ID == ID).FirstOrDefault();
                if (existingPerson != null)
                {
                    testReport = existingPerson.Report;
                    return true;
                }
            }
            testReport = null;
            return false;
        }

        public static Person[] ReaAllPerson()
        {
            List<Person> list = new List<Person>();
            using (var db = new LiteDatabase(DataAddr))
            {
                var History = db.GetCollection<Person>("History");
                var existingPerson = History.FindAll();
                foreach (var person in existingPerson)
                {
                    list.Add(person);
                }
            }

            return list.ToArray();
        }

        public static void ExportExamResult(string ID)
        {
            List<Person> list = new List<Person>();
            using (var db = new LiteDatabase(DataAddr))
            {
                var History = db.GetCollection<Person>("History");
                var existingPerson = History.Find(x => x.ID == ID).FirstOrDefault();
                if (existingPerson != null)
                {

                }
            }
        }



        public class singalTest
        {
            public string FileName { get; set; }
            public string Isack { get; set; }
            public string RepTime { get; set; }
            public singalTest()
            {
                FileName = "unknowed";
                Isack = "unknowed";
                RepTime = "unknowed";
            }
        }

        public class TestReport
        {
            public DateTime TimeTag { get; set; }
            public List<singalTest> ST { get; set; }
            public TestReport()
            {
                ST = new List<singalTest>();
                TimeTag = DateTime.Now;

            }

        }
        //public class info
        //{
        //    public string name { get; set; }
        //    public string gender { get; set; }
        //    public string birthday { get; set; }
        //}
        public class Personinfo
        {
            public string name { get; set; }
            public string gender { get; set; }
            public string birthday { get; set; }
            public Personinfo()
            {
                name = "unknowed";
                gender = "unknowed";
                birthday = "未知";
            }
        }

        public class Person
        {
            public string ID { get; set; }
            public string name { get; set; }
            public string gender { get; set; }
            public string birthday { get; set; }

            public List<TestReport> Report { get; set; }
            public Person()
            {
                Report = new List<TestReport>();
                ID = "unknowed";
                name = "unknowed";
                gender = "unknowed";
                birthday = "未知";

            }

        }

    }


}
